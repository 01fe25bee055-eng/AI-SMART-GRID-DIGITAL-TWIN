"""Streamlit demo dashboard. Values are simulated until hardware integration."""
from pathlib import Path
import streamlit as st
import pandas as pd

st.set_page_config(page_title="AI Smart Grid Digital Twin", page_icon="⚡", layout="wide")
st.title("⚡ AI-Powered Smart Grid Digital Twin")
st.caption("Monitor • Analyze • Predict • Optimize")

st.sidebar.header("Demo controls")
mode = st.sidebar.selectbox("Simulate condition", ["Normal", "Overload", "Fault"])
st.sidebar.warning("Simulation only: this page is not connected to the ESP32 yet.")

examples = {
    "Normal": {"voltage": 6.0, "current": 0.45, "temperature": 32.0},
    "Overload": {"voltage": 5.6, "current": 2.6, "temperature": 54.0},
    "Fault": {"voltage": 0.2, "current": 0.0, "temperature": 31.0},
}
reading = examples[mode]

c1, c2, c3 = st.columns(3)
c1.metric("Voltage (demo)", f'{reading["voltage"]:.2f} V')
c2.metric("Current (demo)", f'{reading["current"]:.2f} A')
c3.metric("Temperature (demo)", f'{reading["temperature"]:.1f} °C')

if mode == "Normal":
    st.success("GRID STATUS: NORMAL (SIMULATED)")
elif mode == "Overload":
    st.warning("GRID STATUS: OVERLOAD (SIMULATED)")
else:
    st.error("GRID STATUS: FAULT (SIMULATED)")

st.subheader("Sensor readings")
chart_data = pd.DataFrame({
    "Measurement": ["Voltage (V)", "Current (A)", "Temperature (°C)"],
    "Demo value": [reading["voltage"], reading["current"], reading["temperature"]],
}).set_index("Measurement")
st.bar_chart(chart_data)

st.subheader("AI prediction")
model_path = Path(__file__).resolve().parents[1] / "ai-model" / "smart_grid_model.joblib"
if model_path.exists():
    try:
        import joblib
        model = joblib.load(model_path)
        features = pd.DataFrame(
            [[reading["voltage"], reading["current"], reading["temperature"]]],
            columns=["voltage", "current", "temperature"],
        )
        prediction = model.predict(features)[0]
        st.info(f"Trained model prediction for simulated values: **{prediction}**")
        st.caption("This is a demonstration using a tiny illustrative dataset, not validated fault detection.")
    except Exception as exc:
        st.warning(f"Could not load model: {exc}")
else:
    st.info("No trained model found yet. Run: python ai-model/train_model.py")

st.subheader("System components")
st.write("ESP32 · ZMPT101B voltage sensor · ACS712 current sensor · DS18B20 temperature sensor · OLED · relay module")
st.caption("All readings on this page are simulated. Real-time ESP32/Wi-Fi integration is a separate next step.")
