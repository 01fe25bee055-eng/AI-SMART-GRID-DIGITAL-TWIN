/*
  AI Smart Grid Digital Twin - ESP32 starter firmware
  Libraries: Adafruit SSD1306, Adafruit GFX, OneWire, DallasTemperature

  SAFETY:
  - Use only isolated low-voltage demo circuits while testing.
  - Do not connect mains voltage to ESP32 or a breadboard.
  - Verify analog sensor outputs stay within the ESP32 ADC input range.
  - Voltage/current conversion factors below are placeholders.
  - Relay polarity depends on the relay module; test with no load first.
*/

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <math.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

const int TEMP_PIN = 4;
const int VOLTAGE_PIN = 35;  // ADC input only
const int CURRENT_PIN = 34;  // ADC input only
const int RELAY1_PIN = 25;
const int RELAY2_PIN = 26;
const int NORMAL_BTN = 27;
const int OVERLOAD_BTN = 14;
const int FAULT_BTN = 13;

OneWire oneWire(TEMP_PIN);
DallasTemperature tempSensor(&oneWire);

// PLACEHOLDERS: calibrate using appropriate isolated reference equipment.
float voltageFactor = 1.0;
float currentAmpsPerVolt = 1.0;
float currentZeroVolts = 1.65; // only valid if verified for your signal circuit

const float CURRENT_LIMIT_A = 2.0; // demonstration threshold only
const float TEMP_LIMIT_C = 60.0;   // demonstration threshold only

// Many relay modules are active LOW. Confirm your module before use.
const int RELAY_ON = LOW;
const int RELAY_OFF = HIGH;

float readVoltageRmsApprox() {
  const int samples = 1000;
  double sum = 0.0, sumSq = 0.0;
  for (int i = 0; i < samples; i++) {
    int raw = analogRead(VOLTAGE_PIN);
    sum += raw;
    sumSq += (double)raw * raw;
    delayMicroseconds(200);
  }
  double mean = sum / samples;
  double variance = sumSq / samples - mean * mean;
  if (variance < 0) variance = 0;
  float adcRms = sqrt(variance);
  float adcVoltsRms = adcRms * 3.3 / 4095.0;
  return adcVoltsRms * voltageFactor;
}

float readCurrentApprox() {
  const int samples = 500;
  long total = 0;
  for (int i = 0; i < samples; i++) {
    total += analogRead(CURRENT_PIN);
    delayMicroseconds(200);
  }
  float rawMean = total / (float)samples;
  float outputVolts = rawMean * 3.3 / 4095.0;
  return fabs(outputVolts - currentZeroVolts) * currentAmpsPerVolt;
}

void setDemoRelays(bool normalState) {
  // Demonstration only. Real protection requires independent, engineered protection.
  digitalWrite(RELAY1_PIN, normalState ? RELAY_ON : RELAY_OFF);
  digitalWrite(RELAY2_PIN, normalState ? RELAY_ON : RELAY_OFF);
}

void setup() {
  Serial.begin(115200);

  pinMode(NORMAL_BTN, INPUT_PULLUP);
  pinMode(OVERLOAD_BTN, INPUT_PULLUP);
  pinMode(FAULT_BTN, INPUT_PULLUP);

  digitalWrite(RELAY1_PIN, RELAY_OFF);
  digitalWrite(RELAY2_PIN, RELAY_OFF);
  pinMode(RELAY1_PIN, OUTPUT);
  pinMode(RELAY2_PIN, OUTPUT);

  analogReadResolution(12);
  analogSetPinAttenuation(VOLTAGE_PIN, ADC_11db);
  analogSetPinAttenuation(CURRENT_PIN, ADC_11db);

  Wire.begin(21, 22);
  tempSensor.begin();

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED not found. Check address and wiring.");
    while (true) delay(1000);
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("AI Smart Grid");
  display.println("Demo firmware");
  display.display();
  delay(1200);
}

void loop() {
  tempSensor.requestTemperatures();
  float temperature = tempSensor.getTempCByIndex(0);
  float voltage = readVoltageRmsApprox();
  float current = readCurrentApprox();

  bool normalPressed = digitalRead(NORMAL_BTN) == LOW;
  bool overloadPressed = digitalRead(OVERLOAD_BTN) == LOW;
  bool faultPressed = digitalRead(FAULT_BTN) == LOW;

  String status = "NORMAL";
  if (faultPressed) {
    status = "FAULT";
  } else if (overloadPressed || current > CURRENT_LIMIT_A ||
             (temperature != DEVICE_DISCONNECTED_C && temperature > TEMP_LIMIT_C)) {
    status = "OVERLOAD";
  } else if (normalPressed) {
    status = "NORMAL";
  }

  setDemoRelays(status == "NORMAL");

  display.clearDisplay();
  display.setCursor(0, 0);
  display.setTextSize(1);
  display.println("SMART GRID DEMO");
  display.print("Status: "); display.println(status);
  display.print("Temp: ");
  if (temperature == DEVICE_DISCONNECTED_C) display.println("Sensor error");
  else { display.print(temperature, 1); display.println(" C"); }
  display.print("Voltage: "); display.print(voltage, 2); display.println(" V*");
  display.print("Current: "); display.print(current, 2); display.println(" A*");
  display.display();

  Serial.print("{\"voltage\":"); Serial.print(voltage, 3);
  Serial.print(",\"current\":"); Serial.print(current, 3);
  Serial.print(",\"temperature\":"); Serial.print(temperature, 2);
  Serial.print(",\"status\":\""); Serial.print(status); Serial.println("\"}");

  delay(500);
}
