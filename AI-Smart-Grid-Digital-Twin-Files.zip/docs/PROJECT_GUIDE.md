# Project setup guide

## 1. Python dashboard
Install Python 3.10+ and run from the repository root:
```bash
pip install -r requirements.txt
streamlit run dashboard/app.py
```
The dashboard initially uses simulated values.

## 2. Train the baseline model
```bash
python ai-model/train_model.py
```
The bundled CSV is a tiny illustrative dataset for testing the workflow only. Do not use it to claim real-world model accuracy.

## 3. ESP32 firmware
Open `esp32-code/SmartGrid.ino` in Arduino IDE. Install:
- Adafruit SSD1306
- Adafruit GFX Library
- OneWire
- DallasTemperature

Select the correct ESP32 board and COM/USB port. Verify OLED I2C address, relay polarity, sensor models, and ADC input ranges before powering.

## 4. Hardware safety and calibration
- A 230 V AC primary is hazardous. Mains work must be done by a qualified electrician with proper enclosure and protection.
- Only use isolated low-voltage demo loads during development.
- Never connect mains voltage to ESP32 pins.
- Check the exact ZMPT101B module input/supply specs. Its output must be safely conditioned before the ESP32 ADC.
- ACS712 modules commonly run at 5 V; condition and verify the output before connecting to a 3.3 V ADC.
- Calibrate voltage/current conversions against suitable references.
- Confirm the relay's default state and logic polarity with no load attached.
- Do not rely on this prototype or its AI output for real electrical protection.
